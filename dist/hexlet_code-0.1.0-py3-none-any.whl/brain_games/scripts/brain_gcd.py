from brain_games.games.gcd import run_gcd_game


def main():
    run_gcd_game()


if __name__ == '__main__':
    main()
