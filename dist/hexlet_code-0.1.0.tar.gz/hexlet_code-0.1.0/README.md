### Hexlet tests and linter status:
[![Actions Status](https://github.com/Xrustic/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Xrustic/python-project-49/actions)

### Maintainability Badge
<a href="https://codeclimate.com/github/Xrustic/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/368258a69f6567c3d242/maintainability" /></a>

### Аскинема
5 часть проекта: https://asciinema.org/a/DkQXMNznvpMda9x1JaDNZDFP3

6 часть проекта:  https://asciinema.org/a/wQ6NPxtsUo2noM9JprHbSsGX2
