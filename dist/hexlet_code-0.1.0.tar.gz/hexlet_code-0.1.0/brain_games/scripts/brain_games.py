from ..cli import welcome_user
##import sys
##sys.path.append(r"home/olga/Projects/python-project-49/brain_games")
##from cli import welcome_user
#!/usr/bin/env python3


def main():
	welcome_user()

if __name__ == '__main__':
    main()

